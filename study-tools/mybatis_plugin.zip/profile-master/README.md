## Build directory file tree
Generated using the shell command `$ sh/tree.sh . > README.md`
<pre>
|---eclipse
||---formatter
|||---JavaCode.xml
|---git
||---.gitconfig
|---idea
||---keymaps
|||---Default-Copy.xml
|---README.md
|---sh
||---tree.sh
</pre>